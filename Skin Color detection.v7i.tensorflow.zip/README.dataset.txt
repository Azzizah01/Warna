# Skin Color detection  > 2024-10-25 4:01am
https://universe.roboflow.com/zia-euctm/skin-color-detection

Provided by a Roboflow user
License: CC BY 4.0

